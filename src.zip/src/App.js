import { Headers } from "./components/Headers";
import { ProductList } from "./components/ProductList";

function App() {
  return (
    <>
    <Headers></Headers>
    <ProductList></ProductList>
    </>
  )
}
export default App;