export const data=[
    {
        id:1,
        title:'cien años de soledad',
        price:100,
        urlImage:'https://images.penguinrandomhouse.com/cover/9780525562443',
        quantity:1
    },
    {
        id:2,
        title:'El señor de los anillos(Trilogia)',
        price:190,
        urlImage:'https://proassetspdlcom.cdnstatics2.com/usuaris/libros/fotos/358/original/portada_pack-trilogia-el-senor-de-los-anillos_j-r-r-tolkien_202206071544.jpg',
        quantity:1
    },
    {
        id:3,
        title:'cuentos de Barrio',
        price:30,
        urlImage:'https://www.librosdelaballena.com/wp-content/uploads/2020/05/cuentos-barro-244x300.png',
        quantity:1
        
    },
    {
        id:4,
        title:'Tierra de Infancia',
        price:30,
        urlImage:'https://marketsvstg.blob.core.windows.net/marketsv/0011705_tierra-de-infancia_510.jpeg',
        quantity:1
    },
    {
        id:5,
        title:'Harry potter pack',
        price:390,
        urlImage:'https://contentv2.tap-commerce.com/cover/large/9789878000473_1.jpg?id_com=1113',
        quantity:1
    },
];